import pandas as pd
from ATPD.atpd_alg import Atpd_algoritm
import json
import sys
from sklearn import metrics
import time

start = time.time()

# all data path defined in configfile
configuration_file = './configfile.txt'

try:
    with open(configuration_file) as json_file: configuration = json.load(json_file)
    pathIn = configuration['pathIn']
    pathTrainFile = pathIn + configuration['trainFile']
    pathTestFile = pathIn + configuration['testFile']
except:
    sys.exit("Error message: configfile error!")

def perf_measure(y_actual, y_hat):
    TP = 0
    FP = 0
    TN = 0
    FN = 0
    for i in range(len(y_hat)):
        if y_actual[i]==y_hat[i]==1:
           TP += 1
        if y_hat[i]==1 and y_actual[i]!=y_hat[i]:
           FP += 1
        if y_actual[i]==y_hat[i]==0:
           TN += 1
        if y_hat[i]==0 and y_actual[i]!=y_hat[i]:
           FN += 1
    return(TP, FP, TN, FN)

TrainFile = pd.read_csv(pathTrainFile)
TrainFile = TrainFile.reset_index()
TestFile = pd.read_csv(pathTestFile)
TestFile = TestFile.reset_index()

#some parameters for R66
Nc = 450
r = 50
rho = 2.0

#some parameters for R50
# Nc = 500
# r = 50
# rho = 1.7

#some parameters for R18
# Nc = 350
# r = 40
# rho = 0.9

cla = Atpd_algoritm(TrainFile,TestFile,Nc,r,rho)
output = cla.findoutlier()

y_true = output['sort_test']['y_true'].tolist()
y_predicted = output['probability']['predicted_label'].tolist()

mear = perf_measure(y_true,y_predicted)

acc = (mear[0]+mear[2])/(mear[0]+mear[1]+mear[2]+mear[3])
detection_rate = mear[0]/(mear[0]+mear[3])
false_alarm = mear[1]/(mear[1]+mear[2])

print('Accuracy: ',acc)
print('Detection Rate: ',detection_rate)
print('False Alarm Rate: ',false_alarm)

y_score = output['probability']['probability']
auc = metrics.roc_auc_score(y_true,y_score)
print ('AUC Score: ',auc)

print('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
print('Computional Time: ', str(time.time()-start)+'s')
