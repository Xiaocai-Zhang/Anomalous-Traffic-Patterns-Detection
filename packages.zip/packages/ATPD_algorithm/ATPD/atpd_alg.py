# this the main algorithm of OFF-ATPD
import numpy as np
import pandas as pd

class Atpd_algoritm:
    def __init__(self, TrainFile, TestFile, Nc, r, rho):
        self.TrainFile = TrainFile
        self.TestFile = TestFile
        self.Nc = Nc
        self.r = r
        self.rho = rho

    # function to divide into two classes of anomaly
    def devide_clas_ano(self):
        output = {}

        Train_ClasA = self.TrainFile[self.TrainFile['len'] >= self.Nc]
        Train_ClasA = Train_ClasA.reset_index()
        Train_ClasB = self.TrainFile[self.TrainFile['len'] < self.Nc]
        Train_ClasB = Train_ClasB.reset_index()
        Test_ClasA = self.TestFile[self.TestFile['len'] >= self.Nc]
        Test_ClasA = Test_ClasA.reset_index()
        Test_ClasB = self.TestFile[self.TestFile['len'] < self.Nc]
        Test_ClasB = Test_ClasB.reset_index()

        output['trainA']=Train_ClasA
        output['trainB'] = Train_ClasB
        output['testA'] = Test_ClasA
        output['testB'] = Test_ClasB
        return output

    def tranProb(self,q1,q3,up,low,dis):
        try:
            mean = (q1+q3)*0.5
            if dis>mean:
                ratio = (up-mean)*2
                prob = (dis-mean)/ratio
                if str(prob) =='nan':
                    return 0
                elif prob>1:
                    return 1
                elif prob<0:
                    return 0
                else:
                    return round(prob,3)
            else:
                ratio = (mean-low) * (-2)
                prob = (dis-mean)/ratio
                if str(prob) == 'nan':
                    return 0
                elif prob>1:
                    return 1
                elif prob<0:
                    return 0
                else:
                    return round(prob,3)
        except:
            return None

    def dis_comp(self,len1,dis1,len2,dis2):
        dis = np.sqrt((len1-len2)**2+(dis1-dis2)**2)
        return dis

    def findoutlier(self):
        out = {}

        trainClaA = Atpd_algoritm.devide_clas_ano(self)['trainA']
        trainClaB = Atpd_algoritm.devide_clas_ano(self)['trainB']

        testClaA = Atpd_algoritm.devide_clas_ano(self)['testA']
        testClaB = Atpd_algoritm.devide_clas_ano(self)['testB']

        sort_test = pd.concat([testClaB,testClaA])

        anomaly_num_clasB = 0
        prob_df = pd.DataFrame(columns=['index','probability','predicted_label'])
        for i in range(len(testClaB)):
            leng = testClaB.iloc[i]['len']
            dis = testClaB.iloc[i]['dis']

            dist1 = trainClaB[trainClaB['len']==(leng-2)]['dis'].tolist()
            dist2 = trainClaB[trainClaB['len'] == (leng-1)]['dis'].tolist()
            dist3 = trainClaB[trainClaB['len'] == leng]['dis'].tolist()
            dist4 = trainClaB[trainClaB['len'] == (leng+1)]['dis'].tolist()
            dist5 = trainClaB[trainClaB['len'] == (leng+2)]['dis'].tolist()

            dis_list = dist1+dist2+dist3+dist4+dist5+[dis]

            q1 = np.percentile(dis_list, 25)
            q3 = np.percentile(dis_list, 75)
            iqr = q3-q1
            up = q3 + self.rho*iqr
            low = q1 - self.rho*iqr

            prob = Atpd_algoritm.tranProb(self,q1,q3,up,low,dis)

            if dis>up or dis<low:
                anomaly_num_clasB = anomaly_num_clasB +1
                print('Class B Anomaly at '+str(i)+'th observation')
                print('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
                label = 1
                df_data = [[i,prob,label]]
                df_data = pd.DataFrame(df_data,columns=['index', 'probability', 'predicted_label'])
                prob_df = pd.concat([prob_df,df_data])
            else:
                label = 0
                df_data = [[i, prob, label]]
                df_data = pd.DataFrame(df_data, columns=['index', 'probability', 'predicted_label'])
                prob_df = pd.concat([prob_df, df_data])

        anomaly_num_clasA = 0
        for i in range(len(testClaA)):
            leng = testClaA.iloc[i]['len']
            dis = testClaA.iloc[i]['dis']

            for j in range(len(trainClaA)):
                leng1 = trainClaA.iloc[j]['len']
                dis1 = trainClaA.iloc[j]['dis']
                distance = Atpd_algoritm.dis_comp(self,leng,dis,leng1,dis1)

                if j==0:
                    near_dis = distance
                else:
                    if distance<near_dis:
                        near_dis = distance

            if near_dis>self.r:
                anomaly_num_clasA = anomaly_num_clasA + 1
                print('Class A Anomaly at '+str(i)+'th observation')
                print('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
                prob = 1
                label = 1
                df_data = [[len(testClaB)+i, prob, label]]
                df_data = pd.DataFrame(df_data, columns=['index', 'probability', 'predicted_label'])
                prob_df = pd.concat([prob_df, df_data])
            else:
                prob = 0
                label = 0
                df_data = [[len(testClaB)+i, prob, label]]
                df_data = pd.DataFrame(df_data, columns=['index', 'probability', 'predicted_label'])
                prob_df = pd.concat([prob_df, df_data])

        anomaly_num = anomaly_num_clasA+anomaly_num_clasB
        print('Totally detected '+str(anomaly_num)+' anomalies')
        print('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')

        out['anomay_num'] = anomaly_num
        out['probability'] = prob_df
        out['sort_test']=sort_test
        return out

