requirements:

pandas=='0.25.0'
scikit-learn=='0.20.3'
numpy=='1.16.4'
numpydoc=='0.8.0'
jsonschema=='3.0.1'