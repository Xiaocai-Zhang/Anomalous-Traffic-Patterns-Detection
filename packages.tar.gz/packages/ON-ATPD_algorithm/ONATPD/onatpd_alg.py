import pandas as pd


class onatpd_algoritm:
    def __init__(self,epsilon):
        self.epsilon = epsilon


    def comp_sim(self,tripA,tripB):
        if len(tripA)>len(tripB):
            sim = 0
            for i in range(len(tripB)):
                dist = (tripA.loc[i,'R']-tripB.loc[i,'R'])**2+(tripA.loc[i,'G']-tripB.loc[i,'G'])**2+(tripA.loc[i,'B']-tripB.loc[i,'B'])**2
                sim = sim + dist
            simi = sim / len(tripB)
            return simi
        else:
            sim = 0
            for j in range(len(tripA)):
                dist = (tripA.loc[j,'R']-tripB.loc[j,'R'])**2+(tripA.loc[j,'G']-tripB.loc[j,'G'])**2+(tripA.loc[j,'B']-tripB.loc[j,'B'])**2
                sim = sim+dist
            simi = sim/len(tripA)
            return simi


    def diff_cal_ct(self,ctA,ctB):
        diffence = 0
        lenA = len(ctA)
        lenB = len(ctB)
        if lenA!=lenB:
            addlist = [255 for i in range(abs(lenA-lenB))]
            addct = pd.DataFrame({'R':addlist,'G':addlist,'B':addlist})
            if lenA>lenB:
                ctB = pd.concat([ctB,addct],sort=True)
            else:
                ctA = pd.concat([ctA, addct],sort=True)
        ctB = ctB.reset_index()
        ctA = ctA.reset_index()

        if len(ctA)==len(ctB):
            for i in range(len(ctA)):
                Diff = ((ctA.loc[i,'R']-ctB.loc[i,'R'])**2+(ctA.loc[i,'G']-ctB.loc[i,'G'])**2+(ctA.loc[i,'B']-ctB.loc[i,'B'])**2)/(255**2+255**2+255**2)

                if Diff<self.epsilon:
                    Diff=0

                diffence = diffence+Diff

        else:
            print('Length not equal!')

        return diffence

